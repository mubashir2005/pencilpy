Instructions to use:

Install the package by 'pip install pencilpy'

# Use pillow or cv2 or any other library to make image readable

Now use the following code to get started with pencilpy

# Get  Pencil Sketch 

from pencilpy import pencil
pencil.sketch('Your image goes here')



# Cartoonify an image
from pencilpy import cartoon
cartoon.cartoonify('Your image goes here')